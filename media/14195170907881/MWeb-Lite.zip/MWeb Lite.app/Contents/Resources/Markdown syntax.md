# Markdown syntax guide suggest version

## Headers

# This is an `<h1>` tag
## This is an `<h2>` tag
###### This is an `<h6>` tag

<!-- more -->

## Emphasis

*This text will be italic*
_This will also be italic_

**This text will be bold**
__This will also be bold__

*You **can** combine them*

## Lists

### Unordered

* Item 1 unordered list `* + SPACE`
* Item 2
	* Item 2a unordered list `* + TAB + SPACE`
	* Item 2b

### Ordered

1. Item 1 ordered list `Number + . + SPACE`
2. Item 2 
3. Item 3
	1. Item 3a ordered list `Number + . + TAB + SPACE`
	2. Item 3b

## Images

![GitHub set up](https://help.github.com/assets/images/site/set-up-git.gif)
Format: ![Alt Text](url)

## Links

An email <example@example.com> link.
[GitHub](http://github.com)
Automatic linking for URLs
Any URL (like <http://www.github.com/>) will be automatically converted into a clickable link.

## Blockquotes

As Kanye West said:
> We're living the future so
> the present is our past.

## Inline code

I think you should use an
`<addr>` `code` element here instead.

## Multi-line code

```
function fancyAlert(arg) {
  if(arg) {
    $.facebox({div:'#foo'})
  }

}
```

## Tables

You can create tables by assembling a list of words and dividing them with hyphens - (for the first row), and then separating each column with a pipe |:

First Header | Second Header
------------ | -------------
Content from cell 1 | Content from cell 2
Content in the first column | Content in the second column


## Strikethrough

Any word wrapped with two tildes (like ~~this~~) will appear crossed out.

## Horizontal Rules

Following lines will produce a horizontal rule:

***

*****

- - -

## Comment And Read More..

<!-- comment -->
<!-- more -->
Actions->Insert Read More Comment *OR* `CMD + .`

## Reference:

<https://guides.github.com/features/mastering-markdown/>



